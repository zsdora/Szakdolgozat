import os
import cv2
import numpy as np
import pandas as pd
from scipy.signal import medfilt
from sklearn import svm
from sklearn import datasets
from joblib import dump
from matplotlib import pyplot as plt
from sklearn.metrics import precision_score, accuracy_score, recall_score, f1_score, confusion_matrix, \
    ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from joblib import dump
from sklearn.linear_model import SGDClassifier

# képek beolvasása
image = cv2.imread('input_image.png', cv2.IMREAD_GRAYSCALE)

# kép blokkokra osztása
Nb = 32
blocks_original = [image[y:y + Nb, x:x + Nb] for y in range(0, image.shape[0], Nb) for x in
                   range(0, image.shape[1], Nb)]

# blokkonként tárolt változók
coexisting_gap_positions_all_blocks = []  # változó a co-existing gap pozíciókhoz
zero_height_gap_bins_coordinates_per_block = []  # pozíciók tárolására szolgáló lista

# K-adik hisztogram elemek ellenőrzéséhez változók
tau = 0.001
w1 = 3

# normalizált hisztogram, flatten kivéve
hist = cv2.calcHist([image], [0], None, [256], [0, 255])
norm_hist = hist / hist.sum()
# hol található 0 height gap bin
zero_height_gap_bins_db = []
# tömb, hogy helyileg hol van 0 height gap bin
zero_height_gap_bins = np.zeros((len(blocks_original), 256), dtype=int)
# IJSR 3.3
# norm. hiszt. zero_height_gap_bin
for k in range(0, 255):
    if norm_hist[k] == 0 and (min(norm_hist[k - 1], norm_hist[k + 1]) > tau or
                              (1 / (2 * w1 + 1)) * np.sum(norm_hist[k - w1:k + w1 + 1]) > tau):
        zero_height_gap_bins_db.append(k)
        zero_height_gap_bins[:, k] = 1

print("zero height:", zero_height_gap_bins)
print("Zero Height Gap Bins:", zero_height_gap_bins_db)
# számoljuk meg a detektált zero-height gap bin-ek számát
Ng = len(zero_height_gap_bins_db)
print("Ng:", Ng)
# ellenőrzés döntési küszöb alapján
decision_threshold = 3
if Ng > decision_threshold:
    print("Kontraszt javítás észlelve.")
else:
    print("Kontraszt javítás nem található.")

# ---------------------------------------Javított rész------------------------------------------------------------

# IJSR 3.4
# blokkokban található 0 height gap binek kiszámítása
Vg = np.zeros((len(blocks_original), 256), dtype=int)

for i in range(len(blocks_original)):
    block_hist_original = cv2.calcHist([blocks_original[i]], [0], None, [256], [0, 256])

    for k in zero_height_gap_bins_db:
        if block_hist_original[k] == 0:
            Vg[i, k] = 1

# 0 height gap binek számolása blokkonként
Ng_per_block = np.sum(Vg, axis=1)
print("Ng_per_block:", Ng_per_block)
print("Vg:", Vg)

# csúcsok pozícióinak meghatározása (ISJR 3.4.3)
# 1. lépés
gap_filled_hist = np.zeros((len(blocks_original), 256), dtype=int)
for i in range(len(blocks_original)):
    for k in zero_height_gap_bins_db:
        if Vg[i, k] == 1:  # üres hézag a blokkban
            neighbors = []
            for j in range(-w1, w1 + 1):
                if 0 <= k + j < 256:
                    neighbors.append(block_hist_original[k + j])

            # környezet átlagával feltölteni az üres hézagot
            gap_filled_hist[i, k] = np.mean(neighbors)

# ellenőrzés, blokk esetén eredeti és gap-filled hisztogram
sample_block_index = 0
print("Original Histogram of Block", sample_block_index, ":",
      cv2.calcHist([blocks_original[sample_block_index]], [0], None, [256], [0, 256]).flatten())
print("Gap-filled Histogram of Block", sample_block_index, ":", gap_filled_hist[sample_block_index])

# 2. lépés
filtered_version = medfilt(gap_filled_hist)

# 3. lépés
Vp = np.zeros((len(blocks_original), 256), dtype=int)
for i in range(len(blocks_original)):
    for k in zero_height_gap_bins_db:
        if Vg[i, k] == 1:  # Üres hézag a blokkban
            # különbség számítása
            diff = abs(gap_filled_hist[i, k] - filtered_version[i, k])

            # csúcs detektálása küszöbérték alapján
            if diff > tau:
                Vp[i, k] = 1
print("Vp:", Vp)

# Cg emailben lévő rész alapján
k = 256
Vk = np.zeros(k)
Cg = np.zeros(k)

for k_index in range(256):
    count = 0
    for i in range(Nb):  # feltétel, hogy az index ne lépje túl a tömb méretét
        if i * 256 + k_index < len(Vk) and Vk[i * 256 + k_index] == 1:
            count += 1

    if count > Nb / 2:
        Vk[k_index] = 1
    else:
        Vk[k_index] = 0
''' 
print("VK:", Vk)
print("Cg:", Cg)
'''

# corrected gap positions
Vgc_i = Vg * Vk
print(Vgc_i)

# B. Gap Based Similarity Measure

# reference vektor
# minden blokkra vonatkozóan a 1-esek száma
num_ones_per_block_i = np.sum(Vg, axis=1)

# blokk, ahol a legtöbb 1-es van
reference_block_index_i = np.argmax(num_ones_per_block_i)

# reference vektor létrehozása
Vgr_i = np.zeros_like(num_ones_per_block_i)
Vgr_i[reference_block_index_i] = 1

# EDR (Error Detection and Recovery) a referenciapozíciós vektorhoz
Omega_gr = np.arange(254)  # omega_gr: 1-től 253-ig terjedő értékek

print("num_ones_per_block_i:", num_ones_per_block_i)
print("Referenciablokk indexe a Vg-ben:", reference_block_index_i)
print("Referenciapozíciós vektor (Vgr_i):", Vgr_i)
print("EDR a referenciapozíciós vektorhoz (Omega_gr):", Omega_gr)

# gap pozícióvektorok közötti megfeleltetés ellenőrzése és összesített hasonlóság kiszámítása
matched_pairs = 0
total_pairs = 0

for i in range(len(Vgr_i)):
    for k in range(256):
        if Vgr_i[i] == 1 and Vgc_i[i, k] == 1:  # Case ➀
            matched_pairs += 1
            total_pairs += 1
        elif Vgr_i[i] == 0 and Vgc_i[i, k] == 1:  # Case ➁
            total_pairs += 1
        elif Vgr_i[i] == 1 and Vgc_i[i, k] == 0:  # Case ➂
            total_pairs += 1

# hasonlóság kiszámítása
similarity = matched_pairs / total_pairs

print("Összesített hasonlóság V^i_gc és Vgr között:", similarity)

# hasonlóság számítása V^i_gc és Vgr között
mig = np.full(len(blocks_original), -1)  # alapértelmezett érték, ha nincs észlelt gap-involved pair

# omega i és omega gr metszetének meghatározása
intersection_indices = np.intersect1d(np.where(Vgr_i == 1)[0], np.where(num_ones_per_block_i > 0)[0])
# print("Intersection Indices for mig:", intersection_indices)
if len(intersection_indices) > 0:
    # hasonlóság számítása az egyenlet alapján
    numerator = np.sum(Vgc_i[intersection_indices] * Vgr_i[intersection_indices])
    denominator = np.sum(Vgc_i[intersection_indices] * Vgr_i[intersection_indices] +
                         (1 - Vgc_i[intersection_indices]) * Vgr_i[intersection_indices] +
                         Vgc_i[intersection_indices] * (1 - Vgr_i[intersection_indices]))
    mig[intersection_indices] = numerator / denominator

print("Hasonlóság V^i_gc és Vgr között (mig):", mig)
# if len(intersection_indices) == 0:
# print("Warning: Intersection indices are empty. Check the conditions for Vgr_i and num_ones_per_block_i.")

# ----------------------------------------Új/javított rész legutóbbi email óta-------------------------------------------------
# C. Peak Based Similarity Measure
# referencia csúcs pozícióvektor létrehozása (Vpr)
Vpr = np.zeros((len(blocks_original), 256), dtype=int)

# N_{R} létrehozása (blokk indexek, ahol m_{g}^i nagyobb, mint tg)
tg = 0.5  # vagy 0.8, ahogy a feladat leírja
NR = [i for i, mgi in enumerate(Ng_per_block) if mgi > tg]

# Debug: Ellenőrzés a NR tartalmáról
print("NR:", NR)

# Vpr létrehozása a referenciablokkok csúcs koordinátáinak összegzésével
for n in NR:
    for k in range(256):
        if np.any(blocks_original[n] > 0):
            Vpr[n, k] = np.sum(blocks_original[n][blocks_original[n] > 0])

print("Vpr:", Vpr)

# EDR kiszámítása a Vpr alapján
Omega_pr = np.array([])
for n in NR:
    if n < len(coexisting_gap_positions_all_blocks):
        Omega_pr = np.union1d(Omega_pr, coexisting_gap_positions_all_blocks[n])

print("Omega_pr:", Omega_pr)

# hasonlóság számítása a V^i_pc és Vpr között
mip = np.zeros(len(blocks_original))  # peak-involved pair értékek
for i in range(len(blocks_original)):
    if i in NR:
        intersection_indices = np.intersect1d(np.where(Vpr[i] > 0)[0], np.where(blocks_original[i] > 0)[0])
        # print(f"Intersection Indices for mip at block {i}:", intersection_indices)
        if len(intersection_indices) > 0:
            mip[i] = np.sum(blocks_original[i][blocks_original[i] > 0])

# ha nincs peak-involved pair, akkor -1
if not np.any(mip):
    mip[:] = -1

print("Ng_per_block:", Ng_per_block)
print("Peak-involved pair (mip):", mip)
print("mip length:", len(mip))
print("mig:", mig)
print("mig length:", len(mig))
print("blocks original length:", len(blocks_original))

# SVM
######################
### Data collection in pandas dataframe
### Minden kép bekerül, most nem kell különválogatni a tanító- és teszthalmazt
######################
# Üres DataFrame létrehozása
df = pd.DataFrame(columns=['label', 'mp', 'mg'])

# képek mappájának elérési útvonala
image_folder = 'UCID Database/UCID Database/UCID1338'

# lista a képek elérési útjainak tárolására
image_paths = [os.path.join(image_folder, filename) for filename in os.listdir(image_folder)
               if filename.endswith('.tif')]

# első 100 képet használjuk
image_paths = image_paths[:10]

# Üres változó a kombinált képek tárolására
combined_images = []
#mig ertekek tarolasara lista
mig_values = []
#mip ertekek tarolasara lista
mip_values = []
# labelek tárolására
labels = []
for img_path in image_paths:
    # Kép beolvasása szürkeárnyalatosan
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

    # Kép méretének meghatározása
    N, M = img.shape

    # Maszk létrehozása
    mask = np.zeros((N, M), dtype=np.uint8)
    center_N = N // 2
    center_M = M // 2
    mask[center_N - 64:center_N + 64, center_M - 64:center_M + 64] = 1

    # CLAHE maszk és eredeti maszk létrehozása
    clahe_mask = mask
    orig_mask = 1 - mask

    # np.set_printoptions(threshold=np.inf)  # Minden elem megjelenítése
    # print(clahe_mask)

    # CLAHE algoritmus létrehozása és alkalmazása
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    img_clahe = clahe.apply(img)

    # Maszkok alkalmazása a képekre
    img_orig_masked = img * orig_mask
    img_clahe_masked = img_clahe * clahe_mask

    # Eredeti és CLAHE maszkolt képek összeadása
    combined_img = img_orig_masked + img_clahe_masked

    # Hozzáadás a kombinált képek listához
    combined_images.append(combined_img)

    # Blokkokra osztás
    Nb = 32
    blocks_combined = [combined_img[y:y + Nb, x:x + Nb] for y in range(0, N, Nb) for x in range(0, M, Nb)]
    clahe_blocks = [clahe_mask[y:y + Nb, x:x + Nb] for y in range(0, N, Nb) for x in range(0, M, Nb)]

    # Labels létrehozása blokkonként a CLAHE maszk alapján
    block_labels = []  # blokkok címkéinek tárolása
    for block, mask_block in zip(blocks_combined, clahe_blocks):
        if np.any(mask_block == 1):
            block_labels.append(1)
        else:
            block_labels.append(0)
    labels.append(block_labels)

    # blokkonként tárolt változók
    coexisting_gap_positions_all_blocks = []  # változó a co-existing gap pozíciókhoz
    zero_height_gap_bins_coordinates_per_block = []  # pozíciók tárolására szolgáló lista

    # K-adik hisztogram elemek ellenőrzéséhez változók
    tau = 0.001
    w1 = 3

    # normalizált hisztogram, flatten kivéve
    hist = cv2.calcHist([image], [0], None, [256], [0, 255])
    norm_hist = hist / hist.sum()
    # hol található 0 height gap bin
    zero_height_gap_bins_db = []
    # tömb, hogy helyileg hol van 0 height gap bin
    zero_height_gap_bins = np.zeros((len(blocks_combined), 256), dtype=int)
    # IJSR 3.3
    # norm. hiszt. zero_height_gap_bin
    for k in range(0, 255):
        if norm_hist[k] == 0 and (min(norm_hist[k - 1], norm_hist[k + 1]) > tau or
                                  (1 / (2 * w1 + 1)) * np.sum(norm_hist[k - w1:k + w1 + 1]) > tau):
            zero_height_gap_bins_db.append(k)
            zero_height_gap_bins[:, k] = 1

    # számoljuk meg a detektált zero-height gap bin-ek számát
    Ng = len(zero_height_gap_bins_db)
    # ellenőrzés döntési küszöb alapján
    decision_threshold = 3
    # if Ng > decision_threshold:
    #     print("Kontraszt javítás észlelve.")
    # else:
    #     print("Kontraszt javítás nem található.")

    # ---------------------------------------Javított rész------------------------------------------------------------

    # IJSR 3.4
    # blokkokban található 0 height gap binek kiszámítása
    Vg = np.zeros((len(blocks_combined), 256), dtype=int)

    for i in range(len(blocks_combined)):
        block_hist_combined = cv2.calcHist([blocks_combined[i]], [0], None, [256], [0, 256])

        for k in zero_height_gap_bins_db:
            if block_hist_combined[k] == 0:
                Vg[i, k] = 1

    # 0 height gap binek számolása blokkonként
    Ng_per_block = np.sum(Vg, axis=1)

    # csúcsok pozícióinak meghatározása (ISJR 3.4.3)
    # 1. lépés
    gap_filled_hist = np.zeros((len(blocks_combined), 256), dtype=int)
    for i in range(len(blocks_combined)):
        for k in zero_height_gap_bins_db:
            if Vg[i, k] == 1:  # üres hézag a blokkban
                neighbors = []
                for j in range(-w1, w1 + 1):
                    if 0 <= k + j < 256:
                        neighbors.append(block_hist_combined[k + j])

                # környezet átlagával feltölteni az üres hézagot
                gap_filled_hist[i, k] = np.mean(neighbors)

    # 2. lépés
    filtered_version = medfilt(gap_filled_hist)

    # 3. lépés
    Vp = np.zeros((len(blocks_combined), 256), dtype=int)
    for i in range(len(blocks_combined)):
        for k in zero_height_gap_bins_db:
            if Vg[i, k] == 1:  # Üres hézag a blokkban
                # különbség számítása
                diff = abs(gap_filled_hist[i, k] - filtered_version[i, k])

                # csúcs detektálása küszöbérték alapján
                if diff > tau:
                    Vp[i, k] = 1

    # Cg emailben lévő rész alapján
    k = 256
    Vk = np.zeros(k)
    Cg = np.zeros(k)

    for k_index in range(256):
        count = 0
        for i in range(Nb):  # feltétel, hogy az index ne lépje túl a tömb méretét
            if i * 256 + k_index < len(Vk) and Vk[i * 256 + k_index] == 1:
                count += 1

        if count > Nb / 2:
            Vk[k_index] = 1
        else:
            Vk[k_index] = 0
    ''' 
    print("VK:", Vk)
    print("Cg:", Cg)
    '''

    # corrected gap positions
    Vgc_i = Vg * Vk
    # print(Vgc_i)

    # B. Gap Based Similarity Measure

    # reference vektor
    # minden blokkra vonatkozóan a 1-esek száma
    num_ones_per_block_i = np.sum(Vg, axis=1)

    # blokk, ahol a legtöbb 1-es van
    reference_block_index_i = np.argmax(num_ones_per_block_i)

    # reference vektor létrehozása
    Vgr_i = np.zeros_like(num_ones_per_block_i)
    Vgr_i[reference_block_index_i] = 1

    # EDR (Error Detection and Recovery) a referenciapozíciós vektorhoz
    Omega_gr = np.arange(254)  # omega_gr: 1-től 253-ig terjedő értékek

    # gap pozícióvektorok közötti megfeleltetés ellenőrzése és összesített hasonlóság kiszámítása
    matched_pairs = 0
    total_pairs = 0

    for i in range(len(Vgr_i)):
        for k in range(256):
            if Vgr_i[i] == 1 and Vgc_i[i, k] == 1:  # Case ➀
                matched_pairs += 1
                total_pairs += 1
            elif Vgr_i[i] == 0 and Vgc_i[i, k] == 1:  # Case ➁
                total_pairs += 1
            elif Vgr_i[i] == 1 and Vgc_i[i, k] == 0:  # Case ➂
                total_pairs += 1

    # hasonlóság kiszámítása
    similarity = matched_pairs / total_pairs

    # hasonlóság számítása V^i_gc és Vgr között
    mig = np.full(len(blocks_combined), -1)  # alapértelmezett érték, ha nincs észlelt gap-involved pair

    # omega i és omega gr metszetének meghatározása
    intersection_indices = np.intersect1d(np.where(Vgr_i == 1)[0], np.where(num_ones_per_block_i > 0)[0])
    # print("Intersection Indices for mig:", intersection_indices)
    if len(intersection_indices) > 0:
        # hasonlóság számítása az egyenlet alapján
        numerator = np.sum(Vgc_i[intersection_indices] * Vgr_i[intersection_indices])
        denominator = np.sum(Vgc_i[intersection_indices] * Vgr_i[intersection_indices] +
                             (1 - Vgc_i[intersection_indices]) * Vgr_i[intersection_indices] +
                             Vgc_i[intersection_indices] * (1 - Vgr_i[intersection_indices]))
        mig[intersection_indices] = numerator / denominator

    mig_values.append(mig)

    # C. Peak Based Similarity Measure
    # referencia csúcs pozícióvektor létrehozása (Vpr)
    Vpr = np.zeros((len(blocks_combined), 256), dtype=int)

    # N_{R} létrehozása (blokk indexek, ahol m_{g}^i nagyobb, mint tg)
    tg = 0.5  # vagy 0.8, ahogy a feladat leírja
    NR = [i for i, mgi in enumerate(Ng_per_block) if mgi > tg]

    # Vpr létrehozása a referenciablokkok csúcs koordinátáinak összegzésével
    for n in NR:
        for k in range(256):
            if np.any(blocks_combined[n] > 0):
                Vpr[n, k] = np.sum(blocks_combined[n][blocks_combined[n] > 0])

    # EDR kiszámítása a Vpr alapján
    Omega_pr = np.array([])
    for n in NR:
        if n < len(coexisting_gap_positions_all_blocks):
            Omega_pr = np.union1d(Omega_pr, coexisting_gap_positions_all_blocks[n])

    # hasonlóság számítása a V^i_pc és Vpr között
    mip = np.zeros(len(blocks_combined))  # peak-involved pair értékek
    for i in range(len(blocks_combined)):
        if i in NR:
            intersection_indices = np.intersect1d(np.where(Vpr[i] > 0)[0], np.where(blocks_combined[i] > 0)[0])
            # print(f"Intersection Indices for mip at block {i}:", intersection_indices)
            if len(intersection_indices) > 0:
                mip[i] = np.sum(blocks_combined[i][blocks_combined[i] > 0])

    # ha nincs peak-involved pair, akkor -1
    if not np.any(mip):
        mip[:] = -1

    mip_values.append(mip)
# Eredeti és CLAHE maszkolt képek megjelenítése (opcionális)
# cv2.imshow('Original Masked Image', img_orig_masked)
# cv2.imshow('CLAHE Masked Image', img_clahe_masked)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
print('combined image: ', combined_images)

# TODO: szürkeárnyalatos képek közepére 128x128-as blokkban végrehajtani clahe(clahe.apply) műveletet
# TODO: for ciklusban minden egyes blokknal kiszamolni mip és mig értékét
print('mip values: ', mip_values)
print('mig values: ', mig_values)
print('labels: ', labels)
# Fill the DataFrame row by row
for i in range(len(combined_images)):
    df['label'] = labels[i]  # 0 vagy 1 attól függően, hogy valódi vagy manipulált a blokk
    df['mp'] = mip_values[i]
    df['mg'] = mig_values[i]

# Printing the DataFrame to verify
print(df)

##########################
## Train-test split
## Tanító- és teszthalmaz szétválogatása
##########################
print('Train-test split ...')
print("labels: ", df['label'].values)
X_all = df[['mp', 'mg']].values
Y_all = df['label'].values
print("X_all:", X_all)
print("Y_all:", Y_all)

X_train, X_test, Y_train, Y_test = train_test_split(X_all, Y_all, test_size=0.2, random_state=42)

#######################################################
# Training with SVM
print('Training SVM')
#######################################################
# defining parameter range
param_grid_svm = {'C': [1, 10, 100],
                  'gamma': [0.01, 0.001, 0.0001],
                  'kernel': ['rbf']}

grid = GridSearchCV(SVC(), param_grid_svm, refit=True, verbose=3)

# unbalanced tanítás (vesztesegfuggveny, SGD alg. lépéshossza(túltanulás elkerüléséhez))
clf = SGDClassifier(loss="hinge", alpha=0.01)
# grid search miatt kell fit
clf.fit(X_train, Y_train)

####################################
#  Evaluate
####################################

y_pred = clf.predict(X_test)
print('y_pred: ', X_test)
print('y_pred: ', y_pred)
print('y_test: ', Y_test)
dump(grid, 'gridsearch_svm2.joblib')  # csak elmentjuk a modellt

#####################################
# mérőszámok szerinti kiértékelés
#####################################
prec_score = precision_score(Y_test, y_pred)
accu_score = accuracy_score(Y_test, y_pred)
rec_score = recall_score(Y_test, y_pred)
f1 = f1_score(Y_test, y_pred)
conf_matrix = confusion_matrix(Y_test, y_pred)
print('precision_score: ', prec_score)
print('accuracy_score: ', accu_score)
print('f1_score: ', f1)
print('recall_score: ', rec_score)
print('confusion_matrix: ', conf_matrix)
conf_disp = ConfusionMatrixDisplay(conf_matrix, display_labels=["original", "manipulated"])
conf_disp.plot()
plt.show()
